# Instagram Story Liker CLI Application

### Application for automatically liking stories of the followers of any public profile

### Setup Instructions:- 

> Requirements:- <br/>
> => python 3.8

### 1. Install all the dependencies with the following command ( for windows )

```python
python install -r requirements.txt
```

### 2. Mention your username, password in the config.env file as directed

### 3. Start the applicattion with the following command ( for windows )

```python
python ./main.py
```